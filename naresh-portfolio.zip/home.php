<!-- Home Section -->
<section id="home" class="hero section dark-background">

<img src="assets/img/background-img.jpg" style="object-fit: contain;" alt="" data-aos="fade-in" class="">

<div class="container" data-aos="fade-up" data-aos-delay="100">
  <h2>Naraish Kumar</h2>
  <p>I'm <span class="typed" data-typed-items="Developer, Designer, Freelancer">Developer</span><span class="typed-cursor typed-cursor--blink" aria-hidden="true"></span><span class="typed-cursor typed-cursor--blink" aria-hidden="true"></span></p>
</div>

</section><!-- /Home Section -->