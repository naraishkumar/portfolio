<?php include 'inc/header.php'; ?>

<?php include 'inc/sidebar.php'; ?>

<?php include 'home.php'; ?>

<?php include 'about.php'; ?>

<?php include 'skills.php'; ?>

<?php include 'resume.php'; ?>

<?php include 'portfolio.php'; ?>

<?php include 'services.php'; ?>

<?php include 'contact.php'; ?>

<?php include 'inc/footer.php'; ?>