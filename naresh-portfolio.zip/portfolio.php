  <!-- Portfolio Section -->
  <section id="portfolio" class="portfolio section light-background">

<!-- Section Title -->
<div class="container section-title" data-aos="fade-up">
  <h2>Portfolio</h2>
  <p>Explore a curated selection of my most impactful projects. Each showcase demonstrates my expertise in crafting innovative solutions and dynamic web experiences. Dive in to see how I bring ideas to life.</p>
</div><!-- End Section Title -->

<div class="container">

  <div class="isotope-layout" data-default-filter="*" data-layout="masonry" data-sort="original-order">

    

    <div class="row gy-4 isotope-container" data-aos="fade-up" data-aos-delay="200">

      <div class="col-lg-4 col-md-6 portfolio-item isotope-item filter-app">
        <div class="portfolio-content h-100">
          <img src="assets/img/portfolio/homey-1.png" class="img-fluid" alt="">
          <div class="portfolio-info">
            <h4>Homey Website</h4>
            <p>For Rent and Sell Apartments & Houses</p>
            <a href="assets/img/portfolio/project-pics/homey-1.png" title="Homey Website" data-gallery="portfolio-gallery-app" class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
            <a href="" title="GitHub" class="details-link"><i class="bi bi-link-45deg"></i></a>
          </div>
        </div>
      </div><!-- End Portfolio Item -->

      <div class="col-lg-4 col-md-6 portfolio-item isotope-item filter-product">
        <div class="portfolio-content h-100">
          <img src="assets/img/portfolio/product-1.jpg" class="img-fluid" alt="">
          <div class="portfolio-info">
            <h4>HEALT Jewellary Website</h4>
            <p>E-Commerce Website</p>
            <a href="assets/img/portfolio/product-1.jpg" title="Product 1" data-gallery="portfolio-gallery-product" class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
            <a href="portfolio-details.php" title="More Details" class="details-link"><i class="bi bi-link-45deg"></i></a>
          </div>
        </div>
      </div><!-- End Portfolio Item -->

      <div class="col-lg-4 col-md-6 portfolio-item isotope-item filter-branding">
        <div class="portfolio-content h-100">
          <img src="assets/img/portfolio/branding-1.jpg" class="img-fluid" alt="">
          <div class="portfolio-info">
            <h4>My Portfolio</h4>
            <p>My Resume</p>
            <a href="assets/img/portfolio/branding-1.jpg" title="Branding 1" data-gallery="portfolio-gallery-branding" class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
            <a href="portfolio-details.php" title="More Details" class="details-link"><i class="bi bi-link-45deg"></i></a>
          </div>
        </div>
      </div><!-- End Portfolio Item -->

      <div class="col-lg-4 col-md-6 portfolio-item isotope-item filter-books">
        <div class="portfolio-content h-100">
          <img src="assets/img/portfolio/books-1.jpg" class="img-fluid" alt="">
          <div class="portfolio-info">
            <h4>Watch's Website</h4>
            <p>E-Commerce Website for Watches</p>
            <a href="assets/img/portfolio/books-1.jpg" title="Branding 1" data-gallery="portfolio-gallery-book" class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
            <a href="portfolio-details.html" title="More Details" class="details-link"><i class="bi bi-link-45deg"></i></a>
          </div>
        </div>
      </div><!-- End Portfolio Item -->

      <div class="col-lg-4 col-md-6 portfolio-item isotope-item filter-app">
        <div class="portfolio-content h-100">
          <img src="assets/img/portfolio/app-2.jpg" class="img-fluid" alt="">
          <div class="portfolio-info">
            <h4>Job-Board Website</h4>
            <p>Just started work on it.</p>
            <a href="assets/img/portfolio/app-2.jpg" title="App 2" data-gallery="portfolio-gallery-app" class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
            <a href="portfolio-details.html" title="More Details" class="details-link"><i class="bi bi-link-45deg"></i></a>
          </div>
        </div>
      </div><!-- End Portfolio Item -->

    </div><!-- End Portfolio Container -->

  
  </div>

</div>

</section><!-- /Portfolio Section -->